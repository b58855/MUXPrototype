//
//  MyAccount.h
//  Mozzie's All-Star Pizza
//
//  Created by Evan on 1/13/14.
//  Copyright (c) 2014 Evan Combs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyAccount : UIViewController
{
    
}
-(IBAction)PressedBack:(id)sender;

@end
