//
//  Cell.m
//  Mozzie's All-Star Pizza
//
//  Created by Evan on 1/14/14.
//  Copyright (c) 2014 Evan Combs. All rights reserved.
//

#import "Cell.h"

@implementation Cell
-(void)SetImage:(NSString*)aImage
{
    image = aImage;
}
-(void)SetName:(NSString*)aName
{
    name = aName;
}


@end
