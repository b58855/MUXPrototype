//
//  ViewController.h
//  Mozzie's All-Star Pizza
//
//  Created by Evan on 1/10/14.
//  Copyright (c) 2014 Evan Combs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Home : UIViewController
{
    IBOutlet UIButton *accountButton;
    IBOutlet UIButton *cartButton;
    IBOutlet UIButton *menuButton;
    IBOutlet UIButton *findLocButton;
    IBOutlet UIButton *signInButton;
}

@end
