//
//  Menu.m
//  Mozzie's All-Star Pizza
//
//  Created by Evan on 1/13/14.
//  Copyright (c) 2014 Evan Combs. All rights reserved.
//

#import "Menu.h"
#import "Cell.h"

@interface Menu ()

@end

@implementation Menu

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    pizzas = [[NSMutableArray alloc]init];
    sides = [[NSMutableArray alloc]init];
    drinks = [[NSMutableArray alloc]init];
    
    Cell *newCell;
    [newCell SetName:@"Custom Pizza"];
    [newCell SetImage:@"customPizza"];
    [pizzas addObject:newCell];
    /*[newCell SetName:@"Supreme"];
    [newCell SetImage:];
    [pizzas addObject:newCell];
    [newCell SetName:@"Meat Lovers"];
    [newCell SetImage:];
    [pizzas addObject:newCell];
    [newCell SetName:@"Veggies"];
    [newCell SetImage:];
    [pizzas addObject:newCell];
    [newCell SetName:@"Hawaiian"];
    [newCell SetImage:];
    [pizzas addObject:newCell];
    [newCell SetName:@"Sicilian"];
    [newCell SetImage:];
    [pizzas addObject:newCell];
    [newCell SetName:@"Chicken Fajita"];
    [newCell SetImage:];
    [pizzas addObject:newCell];
    [newCell SetName:@"Bredsticks"];
    [newCell SetImage:];
    [sides addObject:newCell];
    [newCell SetName:@"Cheesesticks"];
    [newCell SetImage:];
    [sides addObject:newCell];
    [newCell SetName:@"Peperroni Breadsticks"];
    [newCell SetImage:];
    [sides addObject:newCell];
    [newCell SetName:@"Garlic Bread"];
    [newCell SetImage:];
    [sides addObject:newCell];
    [newCell SetName:@"Cheese Dip"];
    [newCell SetImage:];
    [sides addObject:newCell];
    [newCell SetName:@"Hot Wings"];
    [newCell SetImage:];
    [sides addObject:newCell];
    [newCell SetName:@"Pepsi"];
    [newCell SetImage:];
    [drinks addObject:newCell];
    [newCell SetName:@"Diet Pepsi"];
    [newCell SetImage:];
    [drinks addObject:newCell];
    [newCell SetName:@"Mt Dew"];
    [newCell SetImage:];
    [drinks addObject:newCell];
    [newCell SetName:@"Dr Pepper"];
    [newCell SetImage:];
    [drinks addObject:newCell];
    [newCell SetName:@"Mist"];
    [newCell SetImage:];
    [drinks addObject:newCell];*/
    
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
